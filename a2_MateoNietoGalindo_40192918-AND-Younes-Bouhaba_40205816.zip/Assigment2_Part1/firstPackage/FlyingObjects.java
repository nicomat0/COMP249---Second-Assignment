// ----------------------------------------------------
// Part: 1
// Written by: Younes Bouhaba ID 40205816 & Mateo Nieto Galindo 40192918
// ----------------------------------------------------
package firstPackage;
/**
 * 
 * @author Mateo & Jounes 
 * This is the quadcopter class. Derived from the Helicopter class
 *
 */
public abstract class FlyingObjects {

	/**
     * This is a getPrice() method
     * 
     */
    public abstract double getPrice();



}
