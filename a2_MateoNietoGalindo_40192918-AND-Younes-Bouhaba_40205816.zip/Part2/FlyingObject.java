// ----------------------------------------------------
// Part: 2
// Written by: Younes Bouhaba ID 40205816 & Mateo Nieto Galindo 40192918
// ----------------------------------------------------
package Part2;
public class FlyingObject {
	/**
	 * 
	 * @author Mateo & Younes 
	 * This is the quadcopter class. Derived from the Helicopter class
	 *
	 */
	
	/**
     * This is a default constructor
     * 
     */
    FlyingObject(){

    }
    /**
     * This is a copy constructor
     * @param i it takes a flying object
     * 
     */
    FlyingObject(FlyingObject i){

    }
    /**
     * This is a toString method
     * @return returns a string
     * 
     */
    public String toString(){
        return "It does not work since polymorphism does not";
    }
}
